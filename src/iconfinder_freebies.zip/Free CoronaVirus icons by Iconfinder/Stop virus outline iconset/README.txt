Stop virus outline iconset
==========================

Designer: LAFS (https://www.iconfinder.com/nandiny)
