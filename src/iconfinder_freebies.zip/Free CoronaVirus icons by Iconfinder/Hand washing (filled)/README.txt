Hand washing (filled)
=====================

Designer: Arana Graphics (https://www.iconfinder.com/aranagraphics)
