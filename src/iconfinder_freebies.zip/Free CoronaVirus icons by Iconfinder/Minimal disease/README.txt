Minimal disease
===============

Designer: PictureWindow (https://www.iconfinder.com/agoehlert)
