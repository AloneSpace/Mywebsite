Coronavirus Information
=======================

Designer: Laura Reen (https://www.iconfinder.com/laurareen)
License: Creative Commons (Attribution 3.0 Unported) (http://creativecommons.org/licenses/by/3.0/)
